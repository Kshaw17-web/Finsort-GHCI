from finsort.model import train_model
if __name__ == '__main__':
    train_model(csv_path='data/finsort_train.csv')
